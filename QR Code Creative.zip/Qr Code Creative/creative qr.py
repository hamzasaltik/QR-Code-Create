#!/usr/bin/env python3
"""
PyQt5 QR Kod Oluşturucu
- Metin / URL girişi
- Dosya yükleme (max 10 MB kontrolü)
- PNG olarak kaydetme
"""

import sys
import os
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QTextEdit, QPushButton, QFileDialog, QMessageBox,
    QGroupBox, QComboBox, QSpinBox, QColorDialog, QFrame, QSizePolicy
)
from PyQt5.QtGui import QPixmap, QImage, QColor, QFont
from PyQt5.QtCore import Qt, QBuffer, QByteArray, QIODevice
import qrcode
from qrcode.constants import ERROR_CORRECT_L, ERROR_CORRECT_M, ERROR_CORRECT_Q, ERROR_CORRECT_H
from PIL import Image
import io


class QRCodeApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("QR Kod Oluşturucu - PyQt5")
        self.setMinimumSize(700, 600)
        self.resize(800, 700)

        self.qr_image = None          # PIL Image
        self.file_data = None         # bytes from uploaded file
        self.file_name = None

        self.init_ui()

    def init_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QVBoxLayout(central)
        main_layout.setSpacing(12)
        main_layout.setContentsMargins(16, 16, 16, 16)

        # Başlık
        title = QLabel("📱 QR Kod Oluşturucu")
        title.setFont(QFont("Segoe UI", 18, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(title)

        # Uyarı
        warning = QLabel(
            "⚠️ QR kodlar maksimum ~3 KB veri tutabilir. 10 MB dosya sığmaz!\n"
            "Büyük dosyalar için dosyayı Drive/Dropbox'a yükleyip linkini kullanın."
        )
        warning.setStyleSheet(
            "background-color: #fff3cd; color: #856404; padding: 8px; "
            "border-radius: 6px; border: 1px solid #ffc107;"
        )
        warning.setWordWrap(True)
        main_layout.addWidget(warning)

        # === Girdi Bölümü ===
        input_group = QGroupBox("Veri Girişi")
        input_layout = QVBoxLayout(input_group)

        self.text_edit = QTextEdit()
        self.text_edit.setPlaceholderText(
            "Metin veya URL yazın...\n\nÖrnek: https://x.com\nveya\nMerhaba Dünya!"
        )
        self.text_edit.setMinimumHeight(100)
        input_layout.addWidget(self.text_edit)

        file_row = QHBoxLayout()
        self.file_btn = QPushButton("📂 Dosya Seç")
        self.file_btn.clicked.connect(self.select_file)
        self.file_label = QLabel("Dosya seçilmedi")
        self.file_label.setStyleSheet("color: #666;")
        file_row.addWidget(self.file_btn)
        file_row.addWidget(self.file_label, 1)
        self.clear_file_btn = QPushButton("✕")
        self.clear_file_btn.setFixedWidth(36)
        self.clear_file_btn.setToolTip("Dosya seçimini temizle")
        self.clear_file_btn.clicked.connect(self.clear_file)
        file_row.addWidget(self.clear_file_btn)
        input_layout.addLayout(file_row)

        main_layout.addWidget(input_group)

        # === Ayarlar ===
        settings_group = QGroupBox("Ayarlar")
        settings_layout = QHBoxLayout(settings_group)

        # Hata düzeltme
        err_layout = QVBoxLayout()
        err_layout.addWidget(QLabel("Hata Düzeltme:"))
        self.error_combo = QComboBox()
        self.error_combo.addItem("Düşük (L) %7", ERROR_CORRECT_L)
        self.error_combo.addItem("Orta (M) %15", ERROR_CORRECT_M)
        self.error_combo.addItem("Yüksek (Q) %25", ERROR_CORRECT_Q)
        self.error_combo.addItem("En Yüksek (H) %30", ERROR_CORRECT_H)
        self.error_combo.setCurrentIndex(1)
        err_layout.addWidget(self.error_combo)
        settings_layout.addLayout(err_layout)

        # Box size
        box_layout = QVBoxLayout()
        box_layout.addWidget(QLabel("Kutu Boyutu:"))
        self.box_spin = QSpinBox()
        self.box_spin.setRange(5, 20)
        self.box_spin.setValue(10)
        box_layout.addWidget(self.box_spin)
        settings_layout.addLayout(box_layout)

        # Border
        border_layout = QVBoxLayout()
        border_layout.addWidget(QLabel("Kenarlık:"))
        self.border_spin = QSpinBox()
        self.border_spin.setRange(1, 10)
        self.border_spin.setValue(4)
        border_layout.addWidget(self.border_spin)
        settings_layout.addLayout(border_layout)

        # Renkler
        color_layout = QVBoxLayout()
        color_layout.addWidget(QLabel("Renkler:"))
        color_btn_row = QHBoxLayout()
        self.fill_color = QColor("#000000")
        self.back_color = QColor("#FFFFFF")
        self.fill_btn = QPushButton("QR Rengi")
        self.fill_btn.clicked.connect(self.choose_fill_color)
        self.fill_btn.setStyleSheet("background-color: #000000; color: white;")
        self.back_btn = QPushButton("Arka Plan")
        self.back_btn.clicked.connect(self.choose_back_color)
        self.back_btn.setStyleSheet("background-color: #FFFFFF; color: black;")
        color_btn_row.addWidget(self.fill_btn)
        color_btn_row.addWidget(self.back_btn)
        color_layout.addLayout(color_btn_row)
        settings_layout.addLayout(color_layout)

        main_layout.addWidget(settings_group)

        # === Butonlar ===
        btn_row = QHBoxLayout()
        self.generate_btn = QPushButton("🚀 QR Kod Oluştur")
        self.generate_btn.setMinimumHeight(42)
        self.generate_btn.setStyleSheet(
            "QPushButton { background-color: #0d6efd; color: white; font-weight: bold; "
            "border-radius: 6px; font-size: 14px; }"
            "QPushButton:hover { background-color: #0b5ed7; }"
        )
        self.generate_btn.clicked.connect(self.generate_qr)
        btn_row.addWidget(self.generate_btn)

        self.save_btn = QPushButton("💾 PNG Kaydet")
        self.save_btn.setMinimumHeight(42)
        self.save_btn.setEnabled(False)
        self.save_btn.setStyleSheet(
            "QPushButton { background-color: #198754; color: white; font-weight: bold; "
            "border-radius: 6px; font-size: 14px; }"
            "QPushButton:hover { background-color: #157347; }"
            "QPushButton:disabled { background-color: #6c757d; }"
        )
        self.save_btn.clicked.connect(self.save_png)
        btn_row.addWidget(self.save_btn)
        main_layout.addLayout(btn_row)

        # === Önizleme ===
        preview_group = QGroupBox("Önizleme")
        preview_layout = QVBoxLayout(preview_group)
        self.preview_label = QLabel("QR kod burada görünecek")
        self.preview_label.setAlignment(Qt.AlignCenter)
        self.preview_label.setMinimumHeight(280)
        self.preview_label.setStyleSheet(
            "background-color: #f8f9fa; border: 1px dashed #adb5bd; border-radius: 8px;"
        )
        self.preview_label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        preview_layout.addWidget(self.preview_label)
        main_layout.addWidget(preview_group, 1)

        # Durum çubuğu
        self.statusBar().showMessage("Hazır")

    def select_file(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Dosya Seç", "", "Tüm Dosyalar (*.*)"
        )
        if not path:
            return

        size = os.path.getsize(path)
        if size > 10 * 1024 * 1024:
            QMessageBox.critical(self, "Hata", "Dosya 10 MB'dan büyük olamaz!")
            return

        if size > 3000:
            reply = QMessageBox.warning(
                self, "Uyarı",
                f"Dosya boyutu: {size / 1024:.1f} KB\n\n"
                "QR kodlar genelde 3 KB'dan fazla veri tutamaz.\n"
                "Yine de denemek ister misiniz?",
                QMessageBox.Yes | QMessageBox.No
            )
            if reply != QMessageBox.Yes:
                return

        try:
            with open(path, "rb") as f:
                self.file_data = f.read()
            self.file_name = os.path.basename(path)
            self.file_label.setText(f"✅ {self.file_name}  ({size / 1024:.1f} KB)")
            self.file_label.setStyleSheet("color: #198754;")
            # Dosya seçilince metin kutusunu temizle (öncelik dosyada)
            self.text_edit.clear()
            self.statusBar().showMessage(f"Dosya yüklendi: {self.file_name}")
        except Exception as e:
            QMessageBox.critical(self, "Hata", f"Dosya okunamadı:\n{e}")

    def clear_file(self):
        self.file_data = None
        self.file_name = None
        self.file_label.setText("Dosya seçilmedi")
        self.file_label.setStyleSheet("color: #666;")
        self.statusBar().showMessage("Dosya seçimi temizlendi")

    def choose_fill_color(self):
        color = QColorDialog.getColor(self.fill_color, self, "QR Rengi Seç")
        if color.isValid():
            self.fill_color = color
            self.fill_btn.setStyleSheet(
                f"background-color: {color.name()}; color: {'white' if color.lightness() < 128 else 'black'};"
            )

    def choose_back_color(self):
        color = QColorDialog.getColor(self.back_color, self, "Arka Plan Rengi Seç")
        if color.isValid():
            self.back_color = color
            self.back_btn.setStyleSheet(
                f"background-color: {color.name()}; color: {'white' if color.lightness() < 128 else 'black'};"
            )

    def generate_qr(self):
        # Veriyi belirle
        if self.file_data is not None:
            data = self.file_data
        else:
            text = self.text_edit.toPlainText().strip()
            if not text:
                QMessageBox.warning(self, "Uyarı", "Lütfen metin girin veya dosya seçin!")
                return
            data = text

        try:
            qr = qrcode.QRCode(
                version=None,
                error_correction=self.error_combo.currentData(),
                box_size=self.box_spin.value(),
                border=self.border_spin.value(),
            )
            qr.add_data(data)
            qr.make(fit=True)

            img = qr.make_image(
                fill_color=self.fill_color.name(),
                back_color=self.back_color.name()
            )
            self.qr_image = img

            # Önizleme için QPixmap'e çevir
            buf = io.BytesIO()
            img.save(buf, format="PNG")
            buf.seek(0)

            qimg = QImage.fromData(buf.getvalue())
            pixmap = QPixmap.fromImage(qimg)

            # Önizleme alanına sığdır
            scaled = pixmap.scaled(
                self.preview_label.size() - self.preview_label.size() * 0.05,
                Qt.KeepAspectRatio,
                Qt.SmoothTransformation
            )
            self.preview_label.setPixmap(scaled)
            self.save_btn.setEnabled(True)

            version = qr.version
            size_info = f"{len(data)} byte"
            self.statusBar().showMessage(
                f"✅ QR oluşturuldu | Versiyon: {version} | Veri: {size_info}"
            )

        except Exception as e:
            self.qr_image = None
            self.save_btn.setEnabled(False)
            self.preview_label.clear()
            self.preview_label.setText("QR kod burada görünecek")
            QMessageBox.critical(
                self, "Hata",
                f"QR kod oluşturulamadı:\n\n{str(e)}\n\n"
                "Muhtemel neden: Veri çok büyük.\n"
                "QR kodlar maksimum ~2.9 KB binary veri tutabilir."
            )
            self.statusBar().showMessage("Hata oluştu")

    def save_png(self):
        if self.qr_image is None:
            return

        default_name = "qrcode.png"
        if self.file_name:
            default_name = f"qr_{self.file_name}.png"

        path, _ = QFileDialog.getSaveFileName(
            self, "PNG Olarak Kaydet", default_name, "PNG Dosyası (*.png)"
        )
        if path:
            try:
                if not path.lower().endswith(".png"):
                    path += ".png"
                self.qr_image.save(path, "PNG")
                QMessageBox.information(self, "Başarılı", f"QR kod kaydedildi:\n{path}")
                self.statusBar().showMessage(f"Kaydedildi: {path}")
            except Exception as e:
                QMessageBox.critical(self, "Hata", f"Kaydetme hatası:\n{e}")


def main():
    # Yüksek DPI desteği
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)

    app = QApplication(sys.argv)
    app.setStyle("Fusion")

    window = QRCodeApp()
    window.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
