# PyQt5 QR Kod Oluşturucu

## Kurulum

```bash
setup.bat açıyoruz pencere açılıp kapanırsa kuruldu demektir
```

## Çalıştırma

```bash
python qr_pyqt5.py
```

## Özellikler

- Metin / URL girişi
- Dosya seçme (max 10 MB kontrolü)
- Hata düzeltme seviyesi seçimi
- Kutu boyutu ve kenarlık ayarı
- QR rengi ve arka plan rengi seçimi
- Önizleme
- PNG olarak kaydetme

## Önemli Not

QR kodlar maksimum yaklaşık **3 KB** veri tutabilir.  
10 MB dosya sığmaz. Büyük dosyalar için dosyayı Google Drive / Dropbox vb. yükleyip **paylaşım linkini** QR koda yazın.
