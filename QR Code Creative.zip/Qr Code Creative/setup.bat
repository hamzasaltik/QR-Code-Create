echo paketler kuruluyor
pip install PyQt5 qrcode[pil] Pillow